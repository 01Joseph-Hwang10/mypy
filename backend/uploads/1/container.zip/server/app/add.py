

def add_two_numbers(a,b):
	return a+b
